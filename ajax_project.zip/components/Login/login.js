// TODO 1: Get the all of the user accts from the database

// action to perform when login button is clicked
$(".login-button button").on("click", () => {
  // TODO 2: create functionality when login button is clicked
});

// action to perform when create is clicked
$(".create-button button").on("click", () => {
  // TODO 3: create functionality when create button is clicked
});
