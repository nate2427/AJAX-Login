// Action to preform when create button is clicked
$(".create-button button").on("click", () => {
  // TODO 1: create functionality for when the create button is clicked
});

// Action to perform when img is clicked
$(".user-img img").on("click", () => {
  // TODO 2: create functionality when the img is clicked
});

// action to  perform when the login button is clicked
$(".login-button button").on("click", () => {
  // TODO 3: create functionality when login button is clicked
});

// HELPER FUNCTION --> Use function below to help you extract the name from the file uploaded
function extractImg(imgObject) {
  return $("#FileUpload1")[0].files && $("#FileUpload1")[0].files.length
    ? $("#FileUpload1")[0].files[0].name
    : "";
}
